package com.example.assignment2;

import java.util.ArrayList;
import java.util.List;

public class briefInformation{
    private String description;
    private String times;
    private int restausmenuVibe;
    //drinks is an array of Drinks
    public static final briefInformation[] briefInformations = {
            new briefInformation("At Epicure, our celebrated chef Eric Frechon, who holds" +
                    " four Michelin stars, has created a temple of gastronomy that is absolutely French.\n" +
                    "\n" +
                    "His macaroni stuffed with black truffle, artichoke and duck foie gras, gratinée " +
                    "with aged Parmesan is an unforgettable dish that people travel to Paris to experience.\n" +
                    "\n" +
                    "Epicure restaurant can be enjoyed every day of the year, with tables laid in" +
                    " an exquisite garden setting throughout the summer."
                    ,"BREAKFAST: From 7:30am to 10:30am\n"+
                    "LUNCH: Tuesday to Saturday, from 12:00pm to 1:30pm\n" +
                    "DINNER: Tuesday to Saturday, from 7:30pm to 9:30pm\n" +
                    "DRESS CODE: Elegant dress. Wearing a jacket is not compulsory but remains highly recommended\n"
                    , R.drawable.paris),
            new briefInformation("UNDER THE DIRECTION OF CELEBRATED MICHELIN-STARRED CHEF" +
                    " JASON ATHERTON, BERNERS TAVERN IS A GASTRONOMIC GEM IN A TRULY BREATHTAKING SETTING.\n" +
                    "\n" +
                    "LOCATED WITHIN IN THE LONDON EDITION, FITZROVIA, WE OFFER A CONTEMPORARY " +
                    "BRITISH MENU USING THE VERY BEST SEASONAL PRODUCE.\n" +
                    "\n",
                    "SUNDAY – MONDAY\n" +
                    "Breakfast 7:00AM – 10:00AM\n" +
                    "\n" +
                    "TUESDAY – SATURDAY\n" +
                    "Breakfast 7:00AM – 10:00AM\n" +
                    "Dinner 5:00PM – 9.45PM", R.drawable.london),
            new briefInformation("Chef de Cuisine Peter Knogl welcomes his guests at the Cheval" +
                    " Blanc with a symphony of aroma, colour and delicately balanced flavours; artfully" +
                    " prepared from the best that nature has to offer. The Cheval Blanc now ranks among " +
                    "the top 100 restaurants in the world, due to it's team's culinarycreations " +
                    "that enrich French haute cuisine with Mediterranean and Asian influences. A " +
                    "home to innovation and finesse, the Cheval Blanc holds 3 Michelin Stars and 19 GaultMillau points.\n" +
                    "\n" +
                    "Experience for yourself how wonderful and intense culinary delights can be.\n" +
                    "\n" ,
                    "Tuesday to Saturday\n" +
                    "12 noon - 2 pm | 7 pm - 10 pm\n" +
                    "\n" +
                    "Cheval Blanc will also be closed:\n" +
                    "from January 1 to 9, 2023\n" +
                    "from February 19 to March 6, 2023\n" +
                    "from August 1 to 21, 2023", R.drawable.switzerland),

            new briefInformation("At first, it’s the view that takes your breath away: The colourful rooftops of " +
                    "Athens, the Acropolis hill with the Parthenon temple on top that feels so close " +
                    "you can almost touch them and on the other side the Lycabettus hill. SENSE Athens," +
                    " a romantic rooftop restaurant, is conveniently located at the most prestigious " +
                    "spot, on the 7th floor of AthensWas Design Hotel which is in the heart of the " +
                    "historical city of Athens and on the entrance of the main road that leads to " +
                    "the Acropolis hill. Whether you have an al fresco dinner on summer evening or " +
                    "dine in colder weather during winter, this view never ceases to enchant. At " +
                    "the rooftop bar you can enjoy signature cocktails and a panoramic view of the " +
                    "most iconic Athens landmarks.\n" +
                    "\n"
                    ,"Open May to September\n" +
                    "Lunch is served 12:00-19:00 & dinner 20:00-23:00", R.drawable.athena),

            new briefInformation("El Jardín de Orfila is an elegant, welcoming restaurant, exquisite in every detail, " +
                    "imbued with the philosophy of its executive chef, Mario Sandoval, who stresses the" +
                    " importance of using fresh, local ingredients in a menu that emphasises seasonal food.\n" +
                    "\n"
                    ,"EVERYDAY FROM  7:30AM TILL 11:30 AM, 1:30PM TILL 4:00PM, 7:30PM TILL 11:00PM", R.drawable.madrid)
    };
    //Each Drink has a name, description, and an image resource
    private briefInformation(String description, String times, int restausmenuVibe) {

        this.description = description;
        this.times = times;
        this.restausmenuVibe = restausmenuVibe;
    }
    public String getDescription() {
        return description;
    }
    public String getTimes() {
        return times;
    }

    public int getrestausmenuVibe() {
        return restausmenuVibe;
    }
}