package com.example.assignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

public class BriefInfo extends AppCompatActivity {
    public static final String EXTRA_RESTAUID = "RestauId";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_brief_info);

        int RestauId = (Integer)getIntent().getExtras().get(EXTRA_RESTAUID);
        briefInformation restaurants = briefInformation.briefInformations[RestauId];

        TextView description = (TextView)findViewById(R.id.description);
        description.setText(restaurants.getDescription());

        TextView times = (TextView)findViewById(R.id.times);
        times.setText(restaurants.getTimes());

        ImageView restausmenuVibe = (ImageView) findViewById(R.id.restausmenuVibe);
        restausmenuVibe.setImageResource(restaurants.getrestausmenuVibe());

    }

    public void OnClickGoHome2(View view){
        Intent intent = new Intent(BriefInfo.this, MainActivity.class);
        startActivity(intent);
    }

}