package com.example.assignment2;

import android.widget.ImageView;

public class DetailedINformation {

    private String contact;
    private int restausmenuImage1;
    public static final DetailedINformation[] detailedRestauInfo = {
            new DetailedINformation(R.drawable.parismenu1,"TEL:\n"
                    +"+33 (0)1 53 43 43 40\n" +
                    "\n" +
                    "EMAIL: epicure@oetkercollection.com\n" +
                    "ADDRESS: 112 rue du Faubourg Saint-Honoré, 75008 Paris"),
            new DetailedINformation(R.drawable.londonmenu,
                    "TEL: +44 (0)20 7908 7979\n" +
                    "\n" +
                    "EMAIL: BERNERSTAVERN@EDITIONHOTELS.COM"),
            new DetailedINformation(R.drawable.switzerlandmenu, "Cheval Blanc by Peter Knogl\n" +
                    "Blumenrain 8 | CH-4001 Basel | Schweiz\n" +
                    "T +41 61 260 50 07 | chevalblanc@lestroisrois.com\n" +
                    "Grand Hotel LES TROIS ROIS"),
            new DetailedINformation(R.drawable.athensmenu, "5 Dionysiou Areopagitou Str., 11742 Athens, Greece\n" +
                    "(on the 7th floor of AthensWas Hotel)\n" +
                    "T: +30 210 9200240\n" +
                    "E: athens@senserestaurants.com"),
            new DetailedINformation(R.drawable.madridmenu,"Dirección\n" +
                    "C/ Orfila, 6 28010 Madrid, España\n" +
                    "\n" +
                    "Contacto\n" +
                    "Email: bookings@hotelorfila.com\n" +
                    "Teléfono: +34 917 02 77 72")

    };
    private DetailedINformation(int restausmenuImage1, String contact) {
        this.restausmenuImage1 = restausmenuImage1;
        this.contact = contact;
    }
    public int getrestausmenuImage1() {
        return restausmenuImage1;
    }
    public String getcontact(){
        return contact;
    }

}
