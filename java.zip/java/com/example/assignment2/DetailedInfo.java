package com.example.assignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailedInfo extends AppCompatActivity {
    public static final String EXTRA_INFOID = "RestauInfoId";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_info);

        int RestauInfoId = (Integer)getIntent().getExtras().get(EXTRA_INFOID);
        DetailedINformation restaurants = DetailedINformation.detailedRestauInfo[RestauInfoId];

        ImageView restausmenuImage1 = (ImageView) findViewById(R.id.restausmenuImage1);
        restausmenuImage1.setImageResource(restaurants.getrestausmenuImage1());

        TextView contact = (TextView) findViewById(R.id.contact);
        contact.setText(restaurants.getcontact());
    }

    public void OnClickGoHome(View view){
        Intent intent = new Intent(DetailedInfo.this, MainActivity.class);
        startActivity(intent);
    }
}