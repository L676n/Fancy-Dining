package com.example.assignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.AdapterView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Spinner spinner;
    Button briefBtn;
    TextView description;
    int pos = 0;
    long id1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        briefBtn = findViewById(R.id.briefBtn);
        spinner = findViewById(R.id.spinner);
        description = findViewById(R.id.description);

        List<String> spinner_values = new ArrayList<>();
        spinner_values.add(0,"Choose from the list");
        spinner_values.add(1,"Epicure, Paris");
        spinner_values.add(2,"Berners Tavern, London");
        spinner_values.add(3,"Cheval Blanc, Switzerland");
        spinner_values.add(4,"Sense Rooftop Restaurant, Athena");
        spinner_values.add(5,"El Jardín De Orfila, Madrid");

        ArrayAdapter arrayAdapter = new ArrayAdapter(MainActivity.this,
                android.R.layout.simple_dropdown_item_1line, spinner_values);

        spinner.setAdapter(arrayAdapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                pos = position;
                }


            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    public  void onBtnBreClick(View view){
        switch (pos){
                case 1:
                    AccessBrief(0);
                    break;
                case 2:
                    AccessBrief(1);
                    break;
                case 3:
                    AccessBrief(2);
                    break;
                case 4:
                    AccessBrief(3);
                    break;
                case 5:
                    AccessBrief(4);
                    break;
        }
    }

    public void AccessBrief(long id1){
        Intent intent = new Intent(MainActivity.this,
                BriefInfo.class);
        intent.putExtra(BriefInfo.EXTRA_RESTAUID, (int) id1);
        startActivity(intent);
    }

    public  void onBtnDetClick(View view){
        switch (pos){
            case 1:
                AccessDetail(0);
                break;
            case 2:
                AccessDetail(1);
                break;
            case 3:
                AccessDetail(2);
                break;
            case 4:
                AccessDetail(3);
                break;
            case 5:
                AccessDetail(4);
                break;
        }
    }

    public void AccessDetail(long id1){
        Intent intent = new Intent(MainActivity.this,
                DetailedInfo.class);
        intent.putExtra(DetailedInfo.EXTRA_INFOID, (int) id1);
        startActivity(intent);
    }

}